#include <stdio.h>
#include "fun.h"

int main() {
	
	
int List[] = {8,10,20,4,6};

int size = sizeof(List)/sizeof(int);

int smallest = List[0];

smallest = lol(smallest, size, &List);

printf("%d\n",smallest);
system("pause");
return(0);
}
