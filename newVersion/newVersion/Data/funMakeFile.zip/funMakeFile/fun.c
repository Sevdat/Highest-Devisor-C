#include "fun.h"

int lol(int smallest, int size,int* List){
int count = 0;
for (count; count < size; count++) {
if (smallest > List[count]) smallest = List[count];
}
int sizeCopy = -(size + 1);

while (sizeCopy < 0) {
sizeCopy += 1;
if (List[size + sizeCopy] % smallest != 0) {
smallest--;
sizeCopy = -(size + 1);
}
}
return smallest;
}
