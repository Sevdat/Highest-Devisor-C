#ifndef FUN_H
#define FUN_H
int lol(int smallest, int size,int* List);
#endif
